// ONBOARDING O3 — the folder grant lifecycle, end to end over the real relay.
//
// The security claim this file defends: the user's own operating-system folder
// dialog IS the authorization event, the relay learns only opaque ids, the
// grant is visible afterwards, and revoking it takes effect immediately and
// locally. Plus: the helper reconnects by itself after the network drops, so a
// person never has to think about it.
import { execFileSync } from "node:child_process";
import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { RunnerDaemon, WorkspaceRegistry, localHelperStatus } from "@norns/runner";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { PGliteTransactionRunner } from "../src/persistence/v2/database.js";
import { type V2MigrationDatabase, runCurrentV2Migrations } from "../src/persistence/v2/migrate.js";
import { PhaseWorkflowService } from "../src/projects/phaseWorkflowService.js";
import { ProjectResumeService } from "../src/projects/projectResumeService.js";
import { RelationalProjectReadRepository } from "../src/projects/relationalReadRepository.js";
import { RepositoryIngestionService } from "../src/projects/repositoryIngestionService.js";
import { SourceBindingService } from "../src/projects/sourceBindingService.js";
import { StrategyBridgeService } from "../src/projects/strategyBridgeService.js";
import { StrategyWorkflowService } from "../src/projects/strategyWorkflowService.js";
import { type NornsServer, buildServer } from "../src/server.js";
import { RelayStores } from "../src/stores.js";
import { UserStore } from "../src/users/store.js";
import { listen, testAdminToken, waitFor } from "./helpers.js";

describe.sequential("ONBOARDING O3 folder grants", () => {
  let pg: PGlite;
  let server: NornsServer;
  let daemon: RunnerDaemon;
  let registry: WorkspaceRegistry;
  let token: string;
  let url: string;
  let dataDir: string;
  let chosen: string;

  beforeEach(async () => {
    pg = new PGlite();
    await pg.exec(
      "CREATE ROLE norns_app NOLOGIN; CREATE TABLE norns_state (key TEXT PRIMARY KEY, snapshot JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT now());",
    );
    await runCurrentV2Migrations(pg as unknown as V2MigrationDatabase);
    const users = new UserStore();
    token = testAdminToken(users);
    const transactions = new PGliteTransactionRunner(pg);
    server = await buildServer({
      stores: new RelayStores(),
      users,
      projects: new RelationalProjectReadRepository(transactions, "onboarding-o3"),
      phase3: {
        sourceBindings: new SourceBindingService(transactions),
        ingestion: new RepositoryIngestionService(transactions),
        phases: new PhaseWorkflowService(transactions),
        strategies: new StrategyWorkflowService(transactions),
        bridge: new StrategyBridgeService({
          transactions,
          phases: new PhaseWorkflowService(transactions),
          strategies: new StrategyWorkflowService(transactions),
        }),
        resume: new ProjectResumeService(transactions),
      },
      localProjectOnboardingReady: true,
      publicOrigin: "https://relay.example",
    });
    url = await listen(server);

    // The folder the person will "pick" in their own OS dialog. Nothing is
    // pre-approved: this test starts from a helper with zero configuration.
    const home = mkdtempSync(join(tmpdir(), "norns-o3-home-"));
    chosen = join(home, "my-project");
    mkdirSync(chosen);
    execFileSync("git", ["-C", chosen, "init", "-b", "main"]);
    execFileSync("git", ["-C", chosen, "config", "user.email", "test@norns.invalid"]);
    execFileSync("git", ["-C", chosen, "config", "user.name", "Norns Test"]);
    writeFileSync(join(chosen, "README.md"), "test\n");
    execFileSync("git", ["-C", chosen, "add", "README.md"]);
    execFileSync("git", ["-C", chosen, "commit", "-m", "initial"]);

    dataDir = mkdtempSync(join(tmpdir(), "norns-o3-helper-"));
    registry = new WorkspaceRegistry(dataDir, async () => chosen);
    daemon = new RunnerDaemon({
      serverUrl: url,
      runnerId: "helper",
      dataDir,
      workspaces: registry,
      heartbeatMs: 500,
      // Slow enough that the "network is down" window is observable in a test;
      // in production the base is 150ms with jitter up to 30s.
      reconnectDelayMs: 400,
      reconnectMaxDelayMs: 800,
    });
  });

  afterEach(async () => {
    daemon?.stop();
    await server?.app.close();
    await pg?.close();
  });

  const api = (path: string, init?: RequestInit) =>
    fetch(`${url}${path}`, {
      ...init,
      headers: {
        authorization: `Bearer ${token}`,
        ...(init?.body ? { "content-type": "application/json" } : {}),
        ...(init?.headers ?? {}),
      },
    });

  const pairAndConnect = async () => {
    const pairing = (await (await api("/api/pairing/start", { method: "POST" })).json()) as {
      code: string;
      install_command: string;
    };
    await daemon.pair(pairing.code);
    daemon.connect();
    await waitFor(() => server.connectedRunners().includes("helper"), "helper connected");
    return pairing;
  };

  it("hands the web UI a one-line setup command carrying the one-time code", async () => {
    const started = await api("/api/pairing/start", { method: "POST" });
    const body = (await started.json()) as {
      code: string;
      expires_at: string;
      install_command: string;
      install_command_windows: string;
    };
    expect(body.install_command).toBe(
      `curl -fsSL 'https://relay.example/install/runner.sh' | sh -s -- --server 'https://relay.example' --pair '${body.code}'`,
    );
    expect(body.install_command_windows).toContain(`-Pair '${body.code}'`);
    // Short-lived: the pasted line is only useful for a few minutes.
    expect(Date.parse(body.expires_at) - Date.now()).toBeLessThanOrEqual(10 * 60_000);
  });

  it("reports not_installed, then connected, without any manual configuration", async () => {
    const before = (await (await api("/api/runners/helper/status")).json()) as {
      state: string;
      runner_id: string | null;
      install_command: string;
    };
    expect(before).toMatchObject({ state: "not_installed", runner_id: null });
    expect(before.install_command).toContain("/install/runner.sh");

    await pairAndConnect();
    const after = (await (await api("/api/runners/helper/status")).json()) as {
      state: string;
      runner_id: string;
      runners: { folder_revoke_ready: boolean }[];
    };
    expect(after).toMatchObject({ state: "connected", runner_id: "helper" });
    expect(after.runners[0]?.folder_revoke_ready).toBe(true);
  });

  it("makes the OS folder dialog itself the grant, with no approved root first", async () => {
    await pairAndConnect();
    // Nothing has been configured: the helper has no approved workspaces.
    const empty = (await (await api("/api/runners/helper/workspaces")).json()) as {
      workspaces: unknown[];
    };
    expect(empty.workspaces).toEqual([]);

    const chose = await api("/api/runners/helper/workspaces/choose", {
      method: "POST",
      body: JSON.stringify({}),
    });
    expect(chose.status).toBe(200);
    const selection = (await chose.json()) as {
      selection_token: string;
      repository: { workspace_id: string; repository_id: string };
    };
    expect(selection.repository).toMatchObject({ repository_display_name: "my-project" });
    // The relay never saw the path — not in the selection, not anywhere.
    expect(JSON.stringify(selection)).not.toContain(chosen);

    // The grant is now visible and revocable, which is the whole consent story.
    const granted = (await (await api("/api/runners/helper/workspaces")).json()) as {
      workspaces: { workspace_id: string; label: string }[];
    };
    expect(granted.workspaces).toEqual([
      { workspace_id: selection.repository.workspace_id, label: "my-project" },
    ]);
    expect(JSON.stringify(granted)).not.toContain(chosen);
  });

  it("revokes a grant with an opaque id and stops resolving the repository", async () => {
    await pairAndConnect();
    const selection = (await (
      await api("/api/runners/helper/workspaces/choose", {
        method: "POST",
        body: JSON.stringify({}),
      })
    ).json()) as { repository: { workspace_id: string; repository_id: string } };
    expect(registry.repositoryPath(selection.repository.repository_id)).toBeDefined();

    const revoked = await api("/api/runners/helper/workspaces/revoke", {
      method: "POST",
      body: JSON.stringify({ workspace_id: selection.repository.workspace_id }),
    });
    expect(revoked.status).toBe(200);
    expect(await revoked.json()).toMatchObject({ revoked: true });

    // Revocation is local and immediate: the helper can no longer turn that
    // repository id back into a path, so nothing can be executed against it.
    expect(registry.repositoryPath(selection.repository.repository_id)).toBeUndefined();
    expect(registry.listConfigured()).toEqual([]);
    const listed = (await (await api("/api/runners/helper/workspaces")).json()) as {
      workspaces: unknown[];
    };
    expect(listed.workspaces).toEqual([]);

    // Revoking again is a clean 404, not an error the UI has to explain.
    const again = await api("/api/runners/helper/workspaces/revoke", {
      method: "POST",
      body: JSON.stringify({ workspace_id: selection.repository.workspace_id }),
    });
    expect(again.status).toBe(404);
  });

  it("refuses a revocation that names no helper or no workspace", async () => {
    await pairAndConnect();
    const selection = (await (
      await api("/api/runners/helper/workspaces/choose", {
        method: "POST",
        body: JSON.stringify({}),
      })
    ).json()) as { repository: { workspace_id: string } };

    const unknownHelper = await api("/api/runners/unknown-helper/workspaces/revoke", {
      method: "POST",
      body: JSON.stringify({ workspace_id: selection.repository.workspace_id }),
    });
    expect(unknownHelper.status).toBe(409);
    expect(await unknownHelper.json()).toMatchObject({ error: "runner_unavailable" });

    const noWorkspace = await api("/api/runners/helper/workspaces/revoke", {
      method: "POST",
      body: JSON.stringify({}),
    });
    expect(noWorkspace.status).toBe(400);

    const unauthenticated = await fetch(`${url}/api/runners/helper/workspaces/revoke`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ workspace_id: selection.repository.workspace_id }),
    });
    expect(unauthenticated.status).toBe(401);
    // The grant is untouched by any of the refused attempts.
    expect(registry.listConfigured()).toHaveLength(1);
  });

  it("reconnects by itself after the network drops, and the picker keeps working", async () => {
    await pairAndConnect();
    const first = (await (
      await api("/api/runners/helper/workspaces/choose", {
        method: "POST",
        body: JSON.stringify({}),
      })
    ).json()) as { repository: { workspace_id: string } };

    daemon.disconnectNow();
    await waitFor(() => !server.connectedRunners().includes("helper"), "helper dropped");
    const whileDown = (await (await api("/api/runners/helper/status")).json()) as {
      state: string;
      message: string;
    };
    expect(whileDown.state).toBe("disconnected");
    expect(whileDown.message).toContain("not reachable");

    // No human action: the login-item helper comes back on its own.
    await waitFor(() => server.connectedRunners().includes("helper"), "helper reconnected");
    await waitFor(async () => {
      const status = (await (await api("/api/runners/helper/status")).json()) as { state: string };
      return status.state === "connected";
    }, "helper reports connected again");

    // The grant survived the drop and the picker still works.
    const second = (await (
      await api("/api/runners/helper/workspaces/choose", {
        method: "POST",
        body: JSON.stringify({}),
      })
    ).json()) as { repository: { workspace_id: string } };
    expect(second.repository.workspace_id).toBe(first.repository.workspace_id);
  });

  it("answers 'is the helper set up here?' offline, for a stuck person", async () => {
    const before = localHelperStatus("helper", dataDir, registry.listConfigured());
    expect(before).toMatchObject({ runner_id: "helper", paired: false, granted_folders: 0 });

    await pairAndConnect();
    await api("/api/runners/helper/workspaces/choose", {
      method: "POST",
      body: JSON.stringify({}),
    });
    const after = localHelperStatus("helper", dataDir, registry.listConfigured());
    expect(after).toMatchObject({ paired: true, granted_folders: 1 });
    expect(after.folder_labels).toEqual(["my-project"]);
    // Even the local summary reports labels, never paths.
    expect(JSON.stringify(after)).not.toContain(chosen);
  });
});
